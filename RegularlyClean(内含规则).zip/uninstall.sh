rm -rf /data/media/0/Android/RegularlyClean
rm -rf /data/media/0/Android/RegularlyClean_old